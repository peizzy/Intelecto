# Intelecto Jiu Jitsu — site institucional

Site estático de página única (`index.html`), sem build, sem dependências.
Todas as imagens estão embutidas no próprio HTML (base64), então não há
pasta de assets para se preocupar.

## Deploy no Vercel

### Opção A — arrastar e soltar (mais rápido)
1. Acesse https://vercel.com/new
2. Arraste esta pasta inteira (`intelecto-jiu-jitsu-site`) para a área de upload
3. Clique em **Deploy**

### Opção B — Vercel CLI
```bash
npm i -g vercel
cd intelecto-jiu-jitsu-site
vercel
```
Siga as perguntas no terminal (login, nome do projeto, etc.) e confirme.
Para produção direto:
```bash
vercel --prod
```

### Opção C — GitHub + Vercel
1. Crie um repositório novo no GitHub e suba esta pasta:
   ```bash
   cd intelecto-jiu-jitsu-site
   git init
   git add .
   git commit -m "site intelecto jiu jitsu"
   git branch -M main
   git remote add origin <url-do-seu-repo>
   git push -u origin main
   ```
2. Em https://vercel.com/new, importe o repositório
3. Não é preciso configurar build command nem output directory —
   é HTML estático puro. Clique em **Deploy**.

## Depois do deploy
- O Vercel te dá uma URL tipo `intelecto-jiu-jitsu.vercel.app`
- Em **Settings → Domains** dá pra apontar um domínio próprio, se tiver um
- Cole a URL final no link da bio do Instagram (@intelectojiujitsu)

## Editar conteúdo depois
Todo o site é um único arquivo `index.html` — texto, estilos e imagens
juntos. Para alterar algo, edite esse arquivo e suba a alteração de novo
(ou rode `vercel --prod` de novo se estiver usando a CLI).
